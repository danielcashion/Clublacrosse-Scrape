server = 'clublacrosse.database.windows.net'
driver = '{SQL Server}'
username = "sql_admin"
password = 'DCdc4646'
database = "clubstats"
table = "[clubstats].[stg].[tourneymachine_mainpage_data_1]"